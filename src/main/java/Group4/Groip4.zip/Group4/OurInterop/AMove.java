package Group4.OurInterop;

public class AMove {
    public double x;
    public double y;

    public AMove(double x, double y){
        this.x=x;
        this.y=y;
    }

    public AMove(){ }

    public double getX(){
        return x;
    }

    public double getY(){
        return y;
    }
}
